import java.util.ArrayList;
import java.util.Scanner;

class Camera {
    private int id;
    private String brand;
    private String model;
    private int pricePerDay;
    private String status;

    public Camera(int id, String brand, String model, int pricePerDay, String status) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public int getPricePerDay() {
        return pricePerDay;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

class Wallet {
    private int balance;

    public Wallet(int initialBalance) {
        this.balance = initialBalance;
    }

    public int getBalance() {
        return balance;
    }

    public void deposit(int amount) {
        balance += amount;
    }
}

public class CameraRentalApp {
    private static ArrayList<Camera> cameraList = new ArrayList<>();
 

    static {
        cameraList.add(new Camera(1, "Samsung", "DS123", 500, "Available"));
        cameraList.add(new Camera(2, "Sony", "HD214", 500, "Available"));
        cameraList.add(new Camera(3, "Panasonic", "XC", 500, "Available"));
        cameraList.add(new Camera(4, "Canon", "XLR", 500, "Available"));
        cameraList.add(new Camera(5, "Fujitsu", "J5", 500, "Available"));
        cameraList.add(new Camera(6, "Sony", "HD226", 500, "Available"));
        cameraList.add(new Camera(7, "LG", "L123", 500, "Available"));
        cameraList.add(new Camera(8, "Canon", "XPL", 500, "Available"));
        cameraList.add(new Camera(9, "Chroma", "CT", 500, "Available"));
        cameraList.add(new Camera(10, "Canon", "Digital", 123, "Available"));
        cameraList.add(new Camera(11, "Nikon", "DSLR-D7500", 500, "Available"));
        cameraList.add(new Camera(12, "Sony", "DSLR12", 200, "Available"));
        cameraList.add(new Camera(13, "Sony", "SONY1234", 123, "Available"));
        cameraList.add(new Camera(14, "Canon", "5050", 25000, "Available"));
        cameraList.add(new Camera(15, "Nikon", "2050", 500, "Available"));
    }
    private static Wallet userWallet = new Wallet(1000); // Initial wallet balance

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Welcome to Camera Rental App");
            System.out.println("1. My Camera");
            System.out.println("2. Rent a Camera");
            System.out.println("3. View All Cameras");
            System.out.println("4. My Wallet");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    handleMyCamera(scanner);
                    break;
                case 2:
                    rentCamera(scanner);
                    break;
                case 3:
                    viewAllCameras();
                    break;
                case 4:
                    handleMyWallet(scanner);
                    break;
                case 5:
                    System.out.println("Thank you for using the Camera Rental App.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void handleMyCamera(Scanner scanner) {
        while (true) {
            System.out.println("My Camera Options:");
            System.out.println("1. Add Camera");
            System.out.println("2. Remove Camera");
            System.out.println("3. View All Cameras");
            System.out.println("4. Go Back to Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCamera(scanner);
                    break;
                case 2:
                    removeCamera(scanner);
                    break;
                case 3:
                    viewAllCameras();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addCamera(Scanner scanner) {
        System.out.println("Add a New Camera"); 
        System.out.print("Enter Camera Brand: ");
        String brand = scanner.next();
        System.out.print("Enter Camera Model: ");
        String model = scanner.next();
        System.out.print("Enter Per Day Rental Price (INR): ");
        int pricePerDay = scanner.nextInt();

        int newCameraId = cameraList.size() + 1;

        Camera newCamera = new Camera(newCameraId, brand, model, pricePerDay, "Available");
        cameraList.add(newCamera);

        System.out.println("Your camera has been successfully added to the list.");
    }

    

    private static void removeCamera(Scanner scanner) {
        System.out.println("Remove a Camera");

     
        System.out.print("Enter Camera ID to remove: ");
        int cameraIdToRemove = scanner.nextInt();

        
        Camera removedCamera = null;
        for (Camera camera : cameraList) {
            if (camera.getId() == cameraIdToRemove) {
                removedCamera = camera;
                cameraList.remove(camera);
                break;
            }
        }

        if (removedCamera != null) {
        
            removedCamera.setStatus("Removed");
            System.out.println("Camera with ID " + cameraIdToRemove + " has been removed.");

            System.out.println("Available Cameras after removal:");
            viewAvailableCameras();
        } else {
            System.out.println("Camera with ID " + cameraIdToRemove + " not found in the list.");
        }
    }

    private static void viewAvailableCameras() {
        boolean availableCamerasExist = false;
        for (Camera camera : cameraList) {
            if (camera.getStatus().equals("Available")) {
                System.out.println(
                    "Camera ID: " + camera.getId() +
                    ", Brand: " + camera.getBrand() +
                    ", Model: " + camera.getModel() +
                    ", Price (Per Day): " + camera.getPricePerDay()
                );
                availableCamerasExist = true;
            }
        }

        if (!availableCamerasExist) {
            System.out.println("No available cameras at the moment.");
        }
    }

   
    private static void rentCamera(Scanner scanner) {
        System.out.println("Rent a Camera");

        System.out.println("Available Cameras:");
        viewAvailableCameras();

        System.out.print("Enter Camera ID to rent: ");
        int cameraIdToRent = scanner.nextInt();

        Camera selectedCamera = null;
        for (Camera camera : cameraList) {
            if (camera.getId() == cameraIdToRent) {
                selectedCamera = camera;
                break;
            }
        }

        if (selectedCamera != null) {
            if (selectedCamera.getStatus().equals("Available")) {
                int pricePerDay = selectedCamera.getPricePerDay();

                if (userWallet.getBalance() >= pricePerDay) {
                    userWallet.deposit(-pricePerDay); 
                    selectedCamera.setStatus("Rented"); // Set the camera as rented
                    System.out.println("Camera with ID " + cameraIdToRent + " has been successfully rented.");
                } else {
                    System.out.println("Insufficient balance in your wallet to rent this camera.");
                }
            } else {
                System.out.println("Camera with ID " + cameraIdToRent + " is not available for rent.");
            }
        } else {
            System.out.println("Camera with ID " + cameraIdToRent + " not found in the list.");
        }
    }


    private static void viewAllCameras() {
        System.out.println("All Cameras:");
        for (Camera camera : cameraList) {
            System.out.println(
                "Camera ID: " + camera.getId() +
                ", Brand: " + camera.getBrand() +
                ", Model: " + camera.getModel() +
                ", Price (Per Day): " + camera.getPricePerDay() +
                ", Status: " + camera.getStatus()
            );
        }
    }

   
   
    private static void handleMyWallet(Scanner scanner) {
        System.out.println("My Wallet");

      
        System.out.println("Your current wallet balance is: INR " + userWallet.getBalance());

     
        System.out.print("Do you want to deposit more money to your wallet? (yes/no): ");
        String depositChoice = scanner.next();

        if (depositChoice.equalsIgnoreCase("yes")) {
            System.out.print("Enter the amount to deposit: INR ");
            int depositAmount = scanner.nextInt();

         
            userWallet.deposit(depositAmount);

  
            System.out.println("Wallet amount successfully added.");
            System.out.println("Your current wallet balance is: INR " + userWallet.getBalance());
        }
    }

       
    }

